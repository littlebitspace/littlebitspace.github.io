# bitfont.py
#
# by littlebitspace
# https://littlebitspace.com
#
# This script creates a trueType font from cp437 bitmap by running two subprocesses:
# - bitfont-bitmapToSvgs.py
# - bitfont-svgsToFont.py
#
# Example: python bitfont.py "terminal gothic.png" "Terminal Gothic" 1.0 littlebitspace

import subprocess
import sys
from PIL import Image

FILE1 = "bitfont-png2svg.py"
FILE2 = "bitfont-svg2ttf.py"

def main():
    if len(sys.argv) < 3:
        print("Usage: python bitfont.py <fontsheet.png> <Font Name> [version] [copyright]")
        sys.exit(1)

    fontsheet = sys.argv[1]
    font_name = sys.argv[2]
    version = sys.argv[3] if len(sys.argv) >= 4 else "1.0"

    img = Image.open(fontsheet)
    glyph_w = img.width // 16
    glyph_h = img.height // 16
    print(f"Detected glyph size: {glyph_w}x{glyph_h}")

    print(f"\n[1/2] Running {FILE1}...")
    subprocess.check_call([sys.executable, FILE1, fontsheet])

    print(f"\n[2/2] Running {FILE2} with FontForge...")
    if len(sys.argv) >= 5:
      subprocess.check_call([
          "fontforge", "-script", FILE2,
          font_name, str(glyph_w), str(glyph_h), version, sys.argv[4]
      ])
    else:
      subprocess.check_call([
          "fontforge", "-script", FILE2,
          font_name, str(glyph_w), str(glyph_h), version,
      ])

    print("\nBuild complete!")

if __name__ == "__main__":
    main()
