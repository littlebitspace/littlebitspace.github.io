# bitfont-bitmapToSvgs.py
#
# by littlebitspace
# https://littlebitspace.com
#
# This script converts a cp437 bitmap to svg files.
#
# Example: python bitfont-bitmapToSvgs.py "terminal gothic.png"

import sys
import os
from PIL import Image
from pixels2svg import pixels2svg

def main():
    if len(sys.argv) != 2:
        print("Usage: python bitfont-bitmapToSvgs.py <fontsheet.png>")
        sys.exit(1)

    filename = sys.argv[1]
    if not os.path.isfile(filename):
        print(f"Error: file '{filename}' not found.")
        sys.exit(1)

    img = Image.open(filename).convert("RGBA")

    width, height = img.size
    if width % 16 != 0 or height % 16 != 0:
        print(f"Error: image size must be divisible by 16. Got {width}x{height}.")
        sys.exit(1)

    bg_color = img.getpixel((0, 0))

    datas = img.getdata()
    new_data = [
        (0, 0, 0, 0) if item[:3] == bg_color[:3] else (0, 0, 0, 255)
        for item in datas
    ]
    img.putdata(new_data)

    output_folder = "_glyphs"
    os.makedirs(output_folder, exist_ok=True)

    glyph_index = 0
    for row in range(16):
        for col in range(16):
            left = col * width // 16
            upper = row * height // 16
            right = left + width // 16
            lower = upper + height // 16
            glyph_img = img.crop((left, upper, right, lower))

            temp_png_path = f"{output_folder}/temp_{glyph_index}.png"
            glyph_img.save(temp_png_path)

            output_svg_path = f"{output_folder}/glyph_{glyph_index}.svg"
            pixels2svg(temp_png_path, output_svg_path)

            os.remove(temp_png_path)
            glyph_index += 1

    print(f"256 glyphs saved as SVGs in '{output_folder}/'.")

if __name__ == "__main__":
    main()
