BITFONT.py


          `Ld'          ,r            ,
           8!           8:           4!                       _,
           8!,d,  ,db.  `b.Jb.Jb.   "4T*  ,db.    .4b J&, ,Jbs7'  ,sb 
           8f 8!  8!`8|  8! 8! 8!    8!   8!`8|    8! !8  8! 4.  `8!`l
           8! 8!  8! 8!  8! 8! 8!    8!   8! 8!    8! !8  Yl7`8|  8!'
           8! 8!  8l 8;  8l.8; 8;    8!   8l 8;    8!,+8   4, 8;  8! ,
          `4P 8; `*+4"  `*+4"*4"    `*P' `*+4"    `*P `?' 4F=s'  `*4" 
             ,8'
            -"

   _,-`````-.
 ,'.         `.    1. Design the font as a bitmap (using the template provided)
/ :            :      - it has to be a 16x16 canvas of mono-spaced characters
l     j ,--.  ,-\     - keep the empty characters empty!
\`-  ; l  _j,-\ |  2. Run bitfont
 \ ``  ,`'  / |`j  3. Share your font (for free)
  `-.'`.    ``r`
        `=:::::'
                                                                   ,-'```--._
The conversion relies on Pillow, Pixels2svg, and FontForge.      ,'         .`.
You may want to create a virtual environment and install the    ;            : \
dependencies. On Linux, it's done like this:                   /-.  ,--. l     j
                                                               | /-.l_  j :  -'/
|  python3 -m venv .font-venv                                  l'| \  `'.  '' /
|  source .font-venv/bin/activate                               `+`'    ,'`.-'
|  python3 -m pip install pixels2svg                            `:::::='

After that, you can run the scripts with:

|  python3 bitfont.by <fontsheet.png> <font name> [version] [copyright]

   _,-`````-.
 ,'.         `.    If you run into problems, don't expect me to able to help; go
/ :            :   ask someone smarter instead.
l     j ,--.  ,-\
\`-  ; l  _j,-\ |  The software comes as is without any warranties.
 \ ``  ,`'  / |`j
  `-.'`.    ``r`
        `=:::::'

   `Ld' JP   ,   ,  `Ld'     `Ld'    JP   ,
    8!  '   4!  4!   8!       8!     '   4!      _,
    8! .4b "4T^"4T^  8!  ,sb  8!,d, .4b "47^ ,Jbs7' ,b.Jb.  -+bs{  ,db.  ,sb
    8!  8!  8!  8!   8! `8!`l 8f 8!  8!  8!  8! 4.   8! 8!  \_ 8! `8!`F `8!`l
    8!  8!  8!  8!   8!  8!'  8! 8!  8!  8!  Yl7`8|  8! 8!  J ^8!  8!    8!'
    8!  8!  8!  8!   8!  8! , 8l.8;  8!  8!   4, 8;  8!.8; |l. 8!  8! ,  8! ,
   `^P'`^P'`^P' `^P'`^P'`^4" `^+4"  `^P'`^P' 4F=s'  ^8f4"  `Y=^?F `^4"  `^4"
                                                     8!
    (c) 2025 littlebitspace                         ,F?.

